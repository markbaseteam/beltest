#### <span style='color:#8854d0'>Season One</span>
**Main Characters**
- Dark
- Nora

**Secondary Characters**
- Claire
- Henry
- Harlowe
- Bob

**Background Characters**
- Malaki
- Griffin
- General Attic People

**Support Characters (NPCs)**
- Cthulhu

#### Season Two
Main Characters
- Dark
- Nora
- Harlowe

Secondary Characters
- Claire
- Henry
- Malaki
- Elora
- Griffin
- General Attic People

#### Season Three
Main Characters
- Dark
- Nora
- Bob
- !Corruption (Chaos)
