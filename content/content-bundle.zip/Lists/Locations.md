#### Season One
- Rosehill Manor
	- The Attic
	- The Basement
- The Void

#### Seasons Two
- Rosehill Manor
	- The Attic
	- The Roof
	- The Library
- The Void
- Mt Hana

#### Season Three
- Rosehill 
	- The Attic
	- The Roof
	- The Library
- The Void
- The Facility
- New House (not sure where - Darkheart)
- The Beach - #special_location
- Mt Hana (originally Talos, but that’s not possible yet… possible the remnants of the old village that will appear on Mt Hana with the Blessing Tree.) #Corruption3_location

#### Seasons 4
- Rosehill
	- The Attic Broken Reality
	- The Roof
	- The Kitchen
	- The Living Room
	- Maddie’s Room
	- Claire and Henry’s Room
- Nora and Dark’s House
- Havenport
	- Riley
	- Zennow (EOD Temple - #S4_finale)
- Belmont Memorial Hospital
- Mt Hana Caves
- The Facility

#### Season 5 
- Riley
	- Nora’s house
	- The Convent of the Eternal Order
	- Various places
- Dark’s House
- Rose Hill
- Belmont
- Hawkesbury
- Mt Hana
- Talos
- Belmont Memorial Hospital
- The Facility