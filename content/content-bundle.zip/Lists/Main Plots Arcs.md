### Relationships
- - -
#### Season One
(ends with Corruption 1 Event - Nora tries to reset reality and time.)
**Main Relationships**
- Claire and Nora
- Nora and Dark
- Claire and Henry

**Secondary Relationships**
* Nora and Henry
* Nora and Bob
* Henry and Griffin
* Henry and ‘Host’

**Tertiary Relationships**
* Claire and Dark
* Dark and Bob
* Nora and Harlowe
* Nora and Malaki
* Malaki and Henry/Claire

#### Season Two
(ends with Jealousy Games/aka the Burning Heart Saga finale)
**Main Relationships**
* Nora and Dark
* Nora and Claire
* Nora and Harlowe
* Claire and Henry

**Secondary Relationships**
* Harlowe and Dark
* Dark and Bob
* Malaki and Elora
* Henry and Griffin
* Malaki and Griffin
* Abbie and Sath
* Henry and ‘Host’

**Tertiary Relationships**
* Abbie and Simon
* Nora and Griffin
* Nora and basically everyone else in the attic

#### Season Three
(ends with Corruption 3 - Corrupt!Dark on a killing spree)
**Main Relationships**
* Nora and Dark
* Nora and Claire
* Claire and Henry
* Malaki and Elora (not in AAA canon, but in DE canon)
* Chaos and Dark/Darkness

**Secondary Relationships**
* Nora and Harlowe
* Nora and Malaki
* Dark and Bob
* Nora and Akito/Children
* Abbie and Zak
* Henry and Griffin
* Henry and ‘Host’

**Tertiary Relationships**
* Nora and Griffin
* Nora and basically everyone else in the attic
* Dark and whatever he has going on… 
* Abbie and Karen

#### Season Four
(ends with The Hunting of the Snark - Nora goes into labour early and goes missing)
**Main Relationships**
* Nora and Dark (Chaos)
* Nora and Claire
* Abbie and Zak
* Henry and Claire
* Malaki and Elora (not in AAA canon, but in DE canon)

**Secondary Relationships**
* Chaos and Dark/Darkness
* Nora and Malaki
* Nora and Maddie
* Luperco and Tyson
* Nora and Prism
* Abbie and Karen
* Henry and ‘Host’

**Tertiary Relationships**
* Nora and Griffin
* Jess and Tyson
* Dark and Maddie
* Maddie and Claire
* Dark and whatever he has going on…

#### Season 5 (TBA)
(hasn’t begun yet.)
**Main Relationships**
* Dark and Nora
* Nora and Lorenzo
* Chaos and Dark
* Claire and Dark
* Claire and Henry
* Malaki and Elora

**Secondary Relationships**
* Malaki and Sath
* Sath and Phoenix
* Dark and Maddie
