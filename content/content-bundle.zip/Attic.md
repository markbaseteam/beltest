Attic located on the upper floor of Rosehill Manor, Rose Hill, Belmont
