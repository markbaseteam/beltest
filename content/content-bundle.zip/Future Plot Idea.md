* Claire’s history regarding her father gets published in the news.
* Dark or Maddie spill her details to Micah to get him to look into her
* Claire retaliating by doing an interview detailing how Dark was abusing Nora.
